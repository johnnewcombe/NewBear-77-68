; ------------------------------------------------------
; Minimon
; ------------------------------------------------------
;  Original author: ACH, Dec.1978
;
;  DJC+CDC 1980 ? ACIA mods...
;     Using ACIA.B for terminal and ACIA.B for punch data )
;
;  CDC     2018   Convert back to ASM from hex code list
;
; ------------------------------------------------------
;
DATAA   EQU     $F400   ; ACIA.A Data register
CTRLA   EQU     $F401   ; ACIA.A Ctrl/Status
DATAB   EQU     $F402   ; ACIA.B Data register
CTRLB   EQU     $F403   ; ACIA.B Ctrl/Status
;
; Note: Stack (documented as being down from F0D1)
;       has only a limit of F0D0 down to F0E2 
;       ( 18 bytes )
STACK   EQU     $F0D0   ; Top of MINIMON's stack

; Note: CDC: I do not think NMI and IRQ are implemented on 77/68
JNMI    EQU     $F0DD   ; Space for jump to NMI routine
JIRQ    EQU     $F0E0   ; Space for jump to IRQ routine

; Note: Temp storage variable renamed to get T_ prefix
;       as some were sharing names with labels or registers
;
T_SAVE  EQU     $F0E3   ; Temp storage for NEWLINE
T_P     EQU     $F0E5   ;   "     "     "  Z,X
T_X     EQU     $F0E6   ;   "     "     "  Sub
T_Y     EQU     $F0E8   ;   "     "     "  Sub
T_NEW   EQU     $F0EA   ;   "     "     "  Block move
T_M     EQU     $F0EC   ;   "     "     "  ZOUT
T_TMPX  EQU     $F0ED   ;   "     "     "  PRX
T_STRT  EQU     $F0EF   ;   "     "     "  GETADDRESS
T_STOP  EQU     $F0F1   ;   "     "     "  GETADDRESS
T_Z     EQU     $F0F3   ;   "     "     "   . RDX
T_R     EQU     $F0F5   ;   "     "     "     PR
T_Q     EQU     $F0F6   ;   "     "     "  ZIN,DUMP 
T_ABYT  EQU     $F0F7   ;   "     "     "  SET BR.PT.
T_BYTE  EQU     $F0FB   ;   "     "     "  SET BR.PT.
;
PSTACK  EQU     $F0FD   ;   "     "     "     SWI
;
; ----------------------------------------------------- * Original HEX

        ORG     $FC00   ; Start of ROM based code

; -----------------------------------------------------
RD      JSR     RDB_B   ; Input one character           * FC00 BD FD2B
        BEQ     RD      ; Ignore paper tape follower    * FC03 27 FB
        BSR     PR_B    ; Echo character                * FC05 8D 08
        CMPA    #'.     ; Was it a fullstop ?           * FC07 81 2E
        BNE     END_RD  ;                               * FC09 26 03
        JMP     START   ; Yes: Go to start of MINIMON   * FC0B 7E FF8F
END_RD  RTS             ;  No: RETURN                   * FC0E 39

; -----------------------------------------------------
; Print character in A

PR_B    LDAB    CTRLB   ; Get ACIA status byte          * FC0F F6 F403
        BITB    #02     ; Is it busy ?                  * FC12 C5 02
        BEQ     PR_B    ; Yes: Try again                * FC14 27 F9
        STAA    DATAB   ;  No: Send data                * FC16 B7 F402
        INC     T_R     ; Characters printed + One      * FC19 7C F0F5
        RTS             ; RETURN                        * FC1C 39

; -----------------------------------------------------
; Check A contains a HEX character,  Set C.bit on fail

VHEX    CMPA    #$2F    ; A < 30 ?                      * FC1D 81 2F
        BLE     .NoHex  ;  not hex                      * FC1F 2F 0E
        CMPA    #$39    ; A > 39 ?                      * FC21 81 39
        BHI     .NoNum  ;  Not a Numeral                * FC23 22 02
.IsHex  CLC             ; It's OK (clear C bit)         * FC25 0C
        RTS             ; RETURN                        * FC26 39
.NoNum  CMPA    #$40    ; A < 41 ?                      * FC27 81 40
        BLE     .NoHex  ;  not hex                      * FC29 2F 04
        CMPA    #$46    ; A <= 46                       * FC2B 81 46
        BLE     .IsHex  ;  then it is hex               * FC2D 2F F6
.NoHex  SEC             ; Set C bit                     * FC2F 0D
        RTS             ; RETURN                        * FC30 39

; -----------------------------------------------------
; 

BINARY  BITA    #$30    ; Is it a letter ?              * FC31 85 30
        BEQ     LETTA   ; Yes: Got to handle it         * FC33 27 0C
RIDA    ASLA            ;  No: It is a number, so       * FC35 48
        ASLA            ;      shift                    * FC36 48
        ASLA            ;       left                    * FC37 48
        ASLA            ;        4 bits                 * FC38 48
        BITB    #$0     ; Is B a letter ?               * FC39 C5 30
        BEQ     LETTB   ; Yes: Go handle it             * FC3B 27 08
RIDB    ANDB    #$0F    ; Clear 4 high bits in B        * FC35 48
        ABA             ; Form binary character (A=A+B) * FC3F 1B
        RTS             ; RETURN                        * FC40 39
LETTA   ADDA    #$9     ; Make A a binary               * FC41 8B 09
        BRA     RIDA    ;  as before                    * FC43 20 F0
LETTB   ADDB    #$09    ; Make B a binary               * FC45 CB 09
        BRA     RIDB    ;  as before                    * FC47 20 F4

; -----------------------------------------------------
; Read a 4 digit HEX value, put result into X

ZIN     BSR     RD      ; Read a character              * FC49 8D B5
        BSR     VHEX    ; Is it a hex character ?       * FC4B 8D D0
        BCS     .prqmz  ; No: go to print `?`           * FC4D 25 10
        STAA    T_Q     ; Save it                       * FC4F B7 F0F6
        BSR     RD      ; Read 2nd character            * FC52 8D AC
        BSR     VHEX    ; Is it a hex character ?       * FC54 8D C7
        BCS     .prqmz  ; No: go to print `?`           * FC56 25 07
        TAB             ; Yes: Put it into B            * FC58 16
        LDAA    T_Q     ; Retrieve 1st hex char to A    * FC59 B6 F0F6
        BSR     BINARY  ; Convert A:B to binary         * FC5C 8D D3
        RTS             ; RETURN                        * FC5E 39
.prqmz  LDAA    #'?     ; Load `?` into A               * FC5F 86 3F
        BSR     PR_B    ; Print it                      * FC61 8D AC
        BRA     ZIN     ; Go back to start of hex input * FC63 20 E4

; -----------------------------------------------------
; Read 4 hex digits and put value into X

RDX     JSR     PRSP    ; Print a space                 * FC65 BD FD4D
        BSR     ZIN     ; Read 2 digit hex value into A * FC68 8D DF
        STAA    T_Z     ; Save byte (most significant)  * FC6A B7 F0F3
        BSR     ZIN     ; Read 2 digit hex value into A * FC6D 8D DA
        STAA    T_Z+1   ; Save byte (least significant) * FC6F B7 F0F4
        LDX     T_Z     ; Load full 4 hex value into X  * FC72 FE F0F3
        RTS             ; RETURN                        * FC75 39

; -----------------------------------------------------
; Print string FOLLOWING JSR ( terminated by $FF )
;  IE: It starts at the `return addr` put onto the stack by JSR
;  So actual return address needed is past the string
;                       
STRING  TSX             ; Get loc. of return addr to X  * FC76 30
        LDX     0,X     ; Get return addr to X          * FC77 EE 00
        DEX             ; Point to byte before          * FC79 09
AGAIN   INX             ; Point to next byte            * FC7A 08
        LDAA    0,X     ; Get byte to be printed        * FC7B A6 00
        CMPA    #$FF    ; End-string ?                  * FC7D 81 FF
        BEQ     ENDSTR  ; Yes: Go to finish up          * FC7F 27 04
        BSR     PR_B    ; Print the byte                * FC81 8D 8C
        BRA     AGAIN   ; Go back for next byte         * FC83 20 F5
ENDSTR  INS             ; Clean up stack...             * FC85 31
        INS             ;  ( pop off the return addr )  * FC86 31
        JMP     1,X     ; Jump back to caller (RETURN)  * FC87 6E 01

; -----------------------------------------------------
; 
GETADD  BSR     STRING  ; Print string...               * FC89 8D EB
        FCC     " S"    ;                               * FC8B 20 53
        FCB     $FF     ;                               * FC8D FF 
        BSR     RDX     ; Read 4 digit HEX addr value   * FC8E 8D D5
        STX     T_STRT  ; Save it                       * FC90 FF F0EF
        BSR     STRING  ; Print string...               * FC93 8D E1
        FCC     " F"    ;                               * FC95 20 46
        FCB     $FF     ;                               * FC97 FF 
        BSR     RDX     ; Read 4 digit HEX addr value   * FC98 8D CB
        STX     T_STOP  ; Save it                       * FC9A FF F0F1
        RTS             ; RETURN                        * FC9D 39

; -----------------------------------------------------
; Convert value in A to 2 x ASCII hex digits in A and B

ASCII   TAB             ; Copy A to B                   * FC9E 16
        ANDA    #$F0    ; Clear low order 4 bits of A   * FC9F 84 F0
        LSRA            ; Shift                         * FCA1 44
        LSRA            ;  right                        * FCA2 44
        LSRA            ;   4                           * FCA3 44
        LSRA            ;    bits                       * FCA4 44
        CMPA    #$09    ; Letter or number ?            * FCA5 81 09
        BHI     SUBT    ;                               * FCA7 22 0B
        ADDA    #30     ; Make it an ASCII number       * FCA9 8B 30
AND     ANDB    #$0F    ; Clear high order bits of B    * FCAB C4 0F
        CMPB    #$09    ; Letter or number ?            * FCAD C1 09
        BHI     ADD     ;                               * FCAF 22 07
        ADDB    #$30    ; Make it an ASCII number       * FCB1 CB 30
        RTS             ; RETURN                        * FCB3 39
SUBT    ADDA    #$37    ; Make it an ASCI letter        * FCB4 8B 37
        BRA     AND     ; Go to process low order value * FCB6 20 F3
ADD     ADDB    #$37    ; Make it an ASII letter        * FCB8 CB 37
        RTS             ; RETURN                        * FCBA 39

; -----------------------------------------------------
; Print value in X as 4 hex digits

PRX     STX     T_TMPX  ; Save X                        * FCBB FF F0ED
        LDAA    T_TMPX  ; Get high order byte to A      * FCBE B6 F0ED
        BSR     ZOUT    ; Print A as 2 hex digits       * FCC1 8D 06
        LDAA    T_TMPX+1 ; Get low order byte to A      * FCC3 B6 F0EE
        BSR     ZOUT    ; Print A as 2 hex digits       * FCC6 8D 01
        RTS             ; RETURN                        * FCC8 39

; -----------------------------------------------------
; Print value in A as 2 hex digits

ZOUT    BSR     ASCII   ; Convert A to ASCII in A & B   * FCC9 8D D3
        STAB    T_M     ; Save B                        * FCCB F7 F0EC
        JSR     PR_B    ; Print byte in A               * FCCE BD FC0F
        LDAA    T_M     ; Get 2nd byte into A           * FCD1 B6 F0EC
        JSR     PR_B    ; Print byte in A               * FCD4 BD FC0F
        RTS             ; RETURN                        * FCD7 39

; -----------------------------------------------------
; Note: PUNCH altered to use PR_A instead of PR for data

PUNCH   JSR     GETADD  ; Prompt for boundary addresses * FCD8 BD FC89
        LDX     #$0000  ; Zero X                        * FCDB CE 0000
LOOP    BSR     ASCII   ; ..wait                        * FCDE 8D BE
        INX             ;   approximately               * FCE0 08
        BNE     LOOP    ;    5 seconds                  * FCE1 26 FB
        BSR     BEGIN   ; Start of record               * FCE3 8D 14
        LDX     T_STRT  ; Set X to start of data        * FCE5 FE F0EF
        DEX             ;   to be punched               * FCE8 09
WRITE   INX             ; point at next data byte       * FCE9 08
        LDAA    0,X     ; Get data byte to A            * FCEA A6 00
        JSR     PRDATA  ; Punch (print) it              * FCEC BD FEB3
        CPX     T_STOP  ; Was that the last byte ?      * FCEF BC F0F1
        BNE     WRITE   ; No: do the next one           * FCF2 26 F5
        BSR     RDB_B   ; Wait for input                * FCF4 8D 35
        JMP     START   ; (RETURN)                      * FCF6 7E FF8F

BEGIN   LDAA    #'S     ; Punch 2 x `S` chars           * FCF9 86 53
        JSR     PRDATA  ;  to indicate start of         * FCFB BD FEB3
        JSR     PRDATA  ;   data block on tape          * FCFE BD FEB3
BIN     LDAA    #$11    ; Set up ACIA for               * FD01 86 11
        STAA    CTRLA   ; 8.data, 2.stop, /.16 clock    * FD03 B7 F401
        RTS             ; RETURN                        * FD06 39


; -----------------------------------------------------
; Note: LOAD altered to use RDDATA instead of RDB for data

LOAD    JSR     GETADD  ; Prompt for boundary addresses * FD07 BD FC89
.nxt1   JSR     RDDATA  ; Begin to read data            * FD0A BD FEA8
        CMPA    #'S     ;  until 2 x `S` characters     * FD0D 81 53
        BNE     .nxt1   ;   have                        * FD0F 26 F9
        JSR     RDDATA  ;    been                       * FD11 BD FEA8
        CMPA    #'S     ;     read                      * FD14 81 53
        BNE     .nxt1   ;                               * FD16 26 F2
        BSR     BIN     ; Set up ACIA for binary data   * FD18 8D E7
        LDX     T_STRT  ; Set X to start of data        * FD1A FE F0EF
        DEX             ;  to be punched                * FD1D 09
READ    INX             ; point at next data byte       * FD1E 08
        JSR     RDDATA  ; Read a byte into A            * FD1F BD FEA8
        STAA    0,X     ; Store it                      * FD22 A7 00
        CPX     T_STOP  ; Was that the last byte ?      * FD24 BC F0F1
        BNE     READ    ; No: do the next one           * FD27 26 F5
        BRA     STARTA  ; Effectively... `JMP START`    * FD29 20 1F

; -----------------------------------------------------
; Read byte from ACIA.B to A

RDB_B   LDAA    CTRLB   ; Get ACIA.B status byte        * FD2B B6 F403
        BITA    #$01    ; Is byte ready in DATAB        * FD2E 85 01
        BEQ     RDB_B   ; No: Try again                 * FD30 27 F9
        LDAA    DATAB   ; Get the data byte to A        * FD32 B6 F402
        RTS             ; RETURN                        * FD35 39

; -----------------------------------------------------
REGPRT  BSR     PRSP    ; Print a space                 * FD36 8D 15
        LDX     PSTACK  ; Point X at user's stack       * FD38 FE F0FD
        BSR     PR2     ; Print CC                      * FD3B 8D 1C
        BSR     PR2     ; Print B                       * FD3D 8D 1A
        BSR     PR2     ; Print A                       * FD3F 8D 18
        BSR     PR4     ; Print X                       * FD41 8D 10
        BSR     PR4     ; Print PC                      * FD43 8D 0E
        LDX     #PSTACK ; Point X at stack pointer      * FD45 CE F0FD
        BSR     PR4X    ; Print stack pointer           * FD48 8D 0A
STARTA  JMP     START   ; Go to start of MINIMON        * FD4A 7E FF8F

; -----------------------------------------------------
PRSP    LDAA    #$20    ; Put space character in A      * FD4D 86 20
        JSR     PR_B    ; Print it                      * FD4F BD FC0F
        RTS             ; RETURN                        * FD52 39

PR4     INX             ; Point X to next character     * FD53 08
PR4X    LDAA    0,X     ; Get byte pointed to by X      * FD54 ASTRT6 00
        JSR     ZOUT    ; Print it                      * FD56 BD FCC9
PR2     INX             ; Point X to next character     * FD59 08
        LDAA    0,X     ; Get byte pointed to by X      * FD5A A6 00
        JSR     ZOUT    ; Print it                      * FD5C BD FCC9
        BSR     PRSP    ; Print a space                 * FD5F 8D EC
        RTS             ; RETURN                        * FD61 39

; -----------------------------------------------------
BLKMOV  JSR     GETADD  ; Prompt for boundary addresses * FD62 BD FC89
        JSR     STRING  ; Print string...               * FD65 BD FC76
        FCC     " To"   ;                               * FD68 20 54 4F
        FCB     $FF     ;                               * FD6B FF
        JSR     RDX     ; Read 4 hex digit value into X * FD6C BD FC65 
        STX     T_NEW   ; Store it as NEW start address * FD6F FF F0EA
        STX     T_X     ;   "    "                      * FD72 FF F0E6
        LDX     T_STRT  ; Put start address into X      * FD75 FE F0EF
        STX     T_Y     ; Store it                      * FD78 FF F0E8
        BSR     SUB     ; Perform T_X minus T_Y         * FD7B 8D 59
        BPL     DOWN    ; Go to Move downwards          * FD7D 2A 23
        LDX     T_STOP  ; Get the STOP stop address     * FD7F FE F0F1
        INX             ; Add 1 to it                   * FD82 08
        STX     T_STOP  ; and save it                   * FD83 FF F0F1
DO_UP   LDX     T_STRT  ; Get START address             * FD86 FE F0EF
        CPX     T_STOP  ; Compare it with STOP          * FD89 BC F0F1
        BNE     CONT_A  ; Finished ?                    * FD8C 26 03
STARTB  JMP     START   ; Yes: back to MINIMON          * FD8E 7E FF8F
CONT_A  LDAA    0,X     ; No: Get data                  * FD91 A6 00
        INX             ; Point X to next `old` address * FD93 08
        STX     T_STRT  ; and store it                  * FD94 FF F0EF
        LDX     T_NEW   ; get address of NEW location   * FD97 FE F0EA
        STAA    0,X     ; Store the data at NEW address * FD9A A7 00
        INX             ; Point X to next `new` address * FD9C 08
        STX     T_NEW   ; and store it                  * FD9D FF F0EA
        BRA     DO_UP   ; loop back for next byte       * FDA0 20 E4
DOWN    LDX     T_STOP  ; Get end address               * FDA2 FE F0F1
        STX     T_X     ; Store it                      * FDA5 FF F0E6
        BSR     SUB     ; Perform T_X minus T_Y         * FDA8 8D 2C
        ADDA    T_NEW+1 ; Add NEW (low.byte) to A       * FDAA BB F0EB
        ADDB    T_NEW   ; Add NEW (high.byte) to B      * FDAD FB F0EA
        STAA    T_NEW+1 ; Save NEW (low.byte)           * FDB0 B7 F0EB
        STAB    T_NEW   ;         (high.byte)           * FDB3 F7 F0EA
        LDX     T_STRT  ; Get START address             * FDB6 FE F0EF
        DEX             ; subract 1 from X              * FDB9 09
        STX     T_STRT  ; Store it                      * FDBA FF F0EF
DO_DOWN LDX     T_STOP  ; Get STOP address              * FDBD FE F0F1
        CPX     T_STRT  ; Compare it with START address * FDC0 BC F0EF
        BEQ     STARTB  ; Effecively `JMP START`        * FDC3 27 C9
        LDAA    0,X     ; Get data                      * FDC5 A6 00
        DEX             ; Subract 1 from X              * FDC7 09
        STX     T_STOP  ; Store it                      * FDC8 FF F0F1
        LDX     T_NEW   ; Load NEW loc address into X   * FDCB FE F0EA
        STAA    0,X     ; Store the data as NEW address * FDCE A7 00
        DEX             ; Point X to next `new` address * FDD0 09
        STX     T_NEW   ; Store it                      * FDD1 FF F0EA
        BRA     DO_DOWN ; Loop back for next byte       * FDD4 20 E7

; -----------------------------------------------------
SUB     LDX     #T_X    ; Point X to start of T_X data  * FDD6 CE F0E6
        LDAA    1,X     ; A = T_X (low)                 * FDD9 A6 01
        LDAB    0,X     ; B = T_X (high)                * FDDB E6 00
        SUBA    3,X     ; A = A - T_Y (low)             * FDDD A0 03
        SUBB    2,X     ; B = B - T_Y (high)            * FDDF E2 02
        RTS             ; RETURN                        * FDE1 39

; -----------------------------------------------------
CMD_Z   BSR     PRP     ; Print " P " for PC            * FDE2 8D 4F
        JSR     ZIN     ; Get PC address                * FDE4 BD FC49
        STAA    T_P     ; Save it                       * FDE7 B7 F0E5
        BSR     PRD     ; Print " D " for Destination   * FDEA 8D 4F
        JSR     ZIN     ; Get Destination address       * FDEC BD FC49
        SUBA    T_P     ; Destination minus PC to A     * FDEF B0 F0E5
        BLS     BACK    ; Go to `Backwards` process ?   * FDF2 23 17
FORWRD  SUBA    #$02    ; Destination minus 2 to A      * FDF4 80 02
        BMI     ERROR   ; If Destination > 127 : ERROR  * FDF6 2B 17
PRINT   STAA    T_P     ; Save Destination              * FDF8 B7 F0E5
        JSR     STRING  ; Print string...               * FDFB BD FC76
        FCC     " R="   ;                               * FDFE 20 52 3D
        FCB     $FF     ;                               * FE01 FF
        LDAA    T_P     ; Get Destination to A          * FE02 B6 F0E5 
        JSR     ZOUT    ; Print it (in hex)             * FE05 BD FCC9
STARTC  JMP     START   ; Return to MINIMON             * FE08 7E FF8F
BACK    SUBA    #$02    ; Destination minus 2 to A      * FE0B 80 02
        BMI     PRINT   ; If Destination >= 128 : PRINT * FE0D 2B E9
ERROR   JSR     STRING  ; Print string...               * FE0F BD FC76
        FCC     " Ran"  ;                               * FE12 20 52 41
        FCC     "ge!"   ;                               * FE4E 47 45 21
        FCB     #$FF    ;                               * FE19 FF
        BRA     STARTC  ; Finished                      * FE1A 20 EC

; -----------------------------------------------------
CMD_X   BSR     PRP     ; Print " P " for PC            * FE1C 8D 15
        JSR     RDX     ; Get PC address to X (16.bit)  * FE1E BD FC65
        STX     T_Y     ; Store it                      * FE21 FF F0E8
        BSR     PRD     ; Print " D " for Destination   * FE24 8D 15
        JSR     RDX     ; Get Destination address       * FE26 BD FC65
        STX     T_X     ; Store it                      * FE29 FF F0E6
        JSR     SUB     ; X = T_X minus T_Y             * FE2C BD FDD6
        BMI     BACK    ; Go to `Backwards` process ?   * FE2F 2B DA
        BRA     FORWRD  ; Go to `Forwards` process      * FE31 20 C1

; -----------------------------------------------------
PRP     JSR     STRING  ; Print string...               * FE33 BD FC76
        FCC     " P "   ;                               * FE36 20 50 20
        FCB     $FF     ;                               * FE39 FF
        RTS             ; RETURN                        * FE3A 39

; -----------------------------------------------------
PRD     JSR     STRING  ; Print string...               * FE3B BD FC76
        FCC     " D "   ;                               * FE3E 20 44 20
        FCB     $FF     ;                               * FE41 FF
        RTS             ; RETURN                        * FE42 39

; -----------------------------------------------------
MODIFY  JSR     RDX     ; Get address to X              * FE43 BD FC65
STRT    JSR     PRSP    ; Print a space                 * FE46 BD FD4D
        CLR     T_R     ; T_R = 0                       * FE49 7F F0F5
PRz     LDAA    0,X     ; Get byte pointed to by X to A * FE4C A6 00
        JSR     ZOUT    ; Print it as 2.hex digits      * FE4E BD FCC9
WATSIT  JSR     RD      ; Get command character         * FE51 BD FC00
WHAT    CMPA    #$20    ; Is it a space ?               * FE54 81 20
        BNE     ISSLSH  ; No: go test for slash         * FE56 26 0C
CARYON  INX             ; Increment X                   * FE58 08
        LDAA    T_R     ; A = T_R                       * FE59 B6 F0F5
        CMPA    #$16    ; At end of line ?              * FE5C 81 16
        BLE     PRz     ; No: Loop back to continue     * FE5E 2F EC
NEW_1   BSR     NEWLINE ; Print c/r l/f nul             * FE60 8D 35
        BRA     STRT    ; Loop back                     * FE62 20 E2  !! 20 E5 ??

ISSLSH  CMPA    #`/     ; Is it a slash ?               * FE64 81 2F
        BNE     ISCRET  ; No: go test for c/r           * FE66 26 03
        DEX             ; X = X - 1                     * FE68 09
        BRA     NEW_1   ; Loop back (print newline)     * FE69 20 F5

ISCRET  CMPA    #$0D    ; Is it a c/r ?                 * FE6B 81 0D
        BNE     ISHEX   ; No: go test for valid Hex     * FE6D 26 03
        INX             ; X = X + 1                     * FE6F 08
        BRA     NEW_1   ; Loop back (print newline)     * FE70 20 EE

ISHEX   JSR     VHEX    ; Is it a valid hex character ? * FE72 BD FC1D
        BCS     PRQM    ; No: print `?` and ignore      * FE75 25 19
        STAA    T_Q     ; T_Q = A : Save it             * FE77 B7 F0F6
        JSR     RD      ; Get 2nd character             * FE7A BD FC00
        JSR     VHEX    ; Is it a valid hex character ? * FE7D BD FC1D
        BCS     WHAT    ; No: then see what it is       * FE80 25 D2
        TAB             ; B = A                         * FE82 16
        LDAA    T_Q     ; A = T_Q                       * FE83 B6 F0F6
        JSR     BINARY  ; Convert to binary value       * FE86 BD FC31
        STAA    0,X     ; Store it                      * FE89 A7 00
        JSR     PRSP    ; Print a space                 * FE8B BD FD4D
        BRA     CARYON  ; Loop back                     * FE8E 20 C8

PRQM    LDAA    #'?     ; Put `?` into A                * FE90 86 3F
        JSR     PR_B    ; Print it                      * FE92 BD FC0F
        BRA     WATSIT  ; Loop back                     * FE95 20 BA

NEWLINE STX     T_SAVE  ; Save X                        * FE97 FF F0E3
        JSR     STRING  ; Print string...               * FE9A BD FC76
        FCB     $0D,$0A,$00                             * FE9D 0D 0A 00
        FCB     $FF     ;                               * FEA0 FF 
        LDX     T_SAVE  ; Restore X                     * FEA1 FE F0E3
        JSR     PRX     ; Print X                       * FEA4 BD FCBB
        RTS             ; RETURN                        * FEA7 39

; -----------------------------------------------------
; ALTER command replaced by second ACIA I/O routines....

RDDATA  LDAA    CTRLA   ; Get ACIA.A status byte        * FEA8 B6 F401
        BITA    #$01    ; Is byte ready in DATAA        * FEAB 85 01
        BEQ     RDDATA  ; No: Try again                 * FEAD 27 F9
        LDAA    DATAA   ; Get the data byte to A        * FEAF B6 F400
        RTS             ; RETURN                        * FEB2 39

PRDATA  LDAB    CTRLA   ; Get ACIA.A status byte        * FEB3 F6 F401
        BITB    #$02    ; Is it busy ?                  * FEB6 C5 02
        BEQ PRDATA      ; Yes: Try again                * FEB8 27 F9
        STAA    DATAA   ;  No: Send data                * FEBA B7 F400
        INC     T_R     ; Characters printed + One   ?? * FEBD 7C F0F5
        RTS             ; RETURN                        * FEC0 39

; -----------------------------------------------------
        NOP             ; FILLER                        * FEC1 00

; -----------------------------------------------------

GO      JSR     RDX     ; Get address to X (16.bit)     * FEC2 BD FC65
        JSR     RD      ; Right address ?            ?? * FEC5 BD FC00
        LDAA    T_Z+1   ; T_Z.low to A                  * FEC8 B6 F0F4
        LDAB    T_Z     ; T_Z.high to B                 * FECB F6 F0F3
GOTO    LDX     PSTACK  ; Callers stack address to X    * FECE FE F0FD
        STAA    7,X     ; Put new return                * FED1 A7 07
        STAB    6,X     ; address on stack              * FED3 E7 06
        LDS     PSTACK  ; Set up calling programs stack * FED5 BE F0FD
        RTI             ; RETURN-FROM-INTERRUPT (SWI)   * FED8 3B

CONTNU  JSR     RD      ; Read a byte (test for `.`)    * FED9 BD FC00
        CMPA    #'1     ; Is it `1` ?                   * FEDC 81 31
        BNE     .isit2  ; No: go test for `2`           * FEDE 26 10
        LDX     T_ABYT  ; Get address of break.point    * FEE0 FE F0F7
        LDAA    T_BYTE  ; Get saved opcode              * FEE3 B6 F0FB
        STAA    0,X     ; Put it back in the program    * FEE6 A7 00
        LDAA    T_ABYT+1 ; Get address at which         * FEE8 B6 F0F8
        LDAB    T_ABYT  ;   to re-enter program         * FEEB F6 F0F7
        BRA     GOTO    ; Go to calling program         * FEEE 20 DE

.isit2  CMPA    #'2     ; Is it `2`                     * FEF0 81 32
        BEQ     .is2    ; Yes: go process it            * FEF2 27 03
        JMP     START   ; No: Return to MINIMON         * FEF4 7E FF8F
.is2    LDX     T_ABYT+2  ; Get addr. of break.point 2  * FEF7 FE F0F9
        LDAA    T_BYTE+1  ; Get old opcode              * FEFA B6 F0FC
        STAA    0,X     ; Put it back                   * FEFD A7 00
        LDAA    T_BYTE+3 ; Load address to start        * FEFF B6 F0FA
        LDAB    T_BYTE+2 ;  running program at          * FF02 F6 F0F9
        BRA     GOTO    ; Run user program              * FF05 20 C7

; -----------------------------------------------------
DUMP    JSR     GETADD  ; Prompt for boundary addresses * FF07 BD FC89
        LDX     T_STRT  ;                               * FF0A FE F0EF
.dnew   JSR     NEWLINE ; Print c/r l/f nul             * FF0D BD FE97
        LDAA    #$08    ;                               * FF10 86 08
        STAA    T_Q     ; T_Q = 8                       * FF12 B7 F0F6
        DEX             ; X = X - 1                     * FF15 09
.dnxt   INX             ; X = X + 1                     * FF16 08
        JSR     PRSP    ; Print a space                 * FF17 BD FD4D
        LDAA    0,X     ; Get a byte                    * FF1A A6 00
        JSR     ZOUT    ; Print it as 2.hex digits      * FF1C BD FCC9
        CPX     T_STOP  ; Finished ?                    * FF1F BC F0F1
        BNE     .dcnt   ; No: Carry on                  * FF22 26 06
.dend   LDAA    DATAB   ; Get a byte from ACIA (clear)  * FF24 B6 F402
        JMP     START   ; Return to MINIMON             * FF27 7E FF8F
.dcnt   LDAA    CTRLB   ; Read ACIA status              * FF2A B6 F403
        BITA    #$01    ; Stop dump ?                   * FF2D 85 01
        BNE     .dend   ; Yes; go clear ACIA etc        * FF2F 26 F3
        DEC     T_Q     ; New line needed ?             * FF31 7A F0F6
        BNE     .dnxt   ; No: Loop back                 * FF34 26 E0
        INX             ; Print next byte               * FF36 08
        BRA     .dnew   ;  on a new line                * FF37 20 D4

; -----------------------------------------------------
BRPTSET JSR     RD      ; Read a byte (test for `.`)    * FF39 BD FC00
        CMPA    #'1     ; Is it `1` ?                   * FF3C 81 31
        BNE     .Is2b   ; No: go test for `2`           * FF3E 26 12
        JSR     RDX     ; Read addr value into X        * FF40 BD FC65
        LDAA    0,X     ; Get the opcode                * FF43 A6 00
        STAA    T_BYTE  ; Save it                       * FF45 B7 F0FB
        STX     T_ABYT  ; and the address               * FF48 FF F0F7
.same   LDAA    #$3F    ; `SWI` opcode :                * FF4B 86 3F
        STAA    0,X     ;   set the breakpoint          * FF4D A7 00
.endb   JMP     START   ; Return to MINIMON             * FF4F 7E FF8F
.Is2b   CMPA    #'2     ; Is it `2` ?                   * FF52 81 32
        BNE     .endb   ; No: Return to MINIMON         * FF54 26 F9
        JSR     RDX     ; Read address into X           * FF56 BD FC65
        LDAA    0,X     ; Get opcode                    * FF59 A6 00
        STAA    T_BYTE+1 ; Save it                      * FF5B B7 F0FC
        STX     T_ABYT+2 ; Save address                 * F5E FF F0F9
        BRA     .same   ; Set the breakpoint            * FF61 20 E8

; -----------------------------------------------------
HEADER  JSR     STRING  ; print string...               * FF63 BD FC76
        FCC     " CC"   ;                               * FF66 20 43 43
        FCC     " B "   ;                               *      20 42 20
        FCC     " A "   ;                               *      20 41 20 
        FCC     "  X"   ;                               *      20 20 58
        FCC     "   "   ;                               *      20 20 20
        FCC     " PC"   ;                               *      20 50 43
        FCC     "   "   ;                               *      20 20 20
        FCC     "SP"   ;                                *      53 50
        FCB     $FF     ;                               * FF7D FF
        JMP     START   ; Return to MINIMON             * FF7E 7E FF8F 
RESET   LDS     #STACK  ; Set up stack for MINIMON      * FF81 8E F0D0
        LDAA    #$04    ; Reset:                        * FF84 86 03
        STAA    CTRLA   ;   ACIA.A                      * FF86 B7 F401
        STAA    CTRLB   ;   ACIA.B                      * FF89 B7 F403
SWI     STS     PSTACK  ; Save callers stack pointer    * FF8C BF F0FD
START   LDS     #STACK  ; Set up stack for MINMON       * FF8F 8E F0D0
        LDAA    #01     ; Set up                        * FF92 86 01
        STAA    CTRLB   ;   ACIA.B                      * FF94 B7 F403
        STAA    CTRLA   ;   ACIA.A                      * FF97 B7 F401 !
        JSR     STRING  ; Print string...               * FF9A BD FC76
        FCB     $0D,$0A,$2A    ; c/r l/f `*`            * FF9D 0D 0A 2A
        FCB     $FF     ;                               * FFA0 FF
        JSR     RD      ; Read a byte (test for `.`)    * FFA1 BD FC00
        NOP             ;                               * FFA4 00
        NOP             ;                               * FFA5 00
        NOP             ;                               * FFA6 00
        NOP             ;                               * FFA7 00
        NOP             ;                               * FFA8 00
        CMPA    #'S     ; Is it `S` ?                   * FFA9 81 53
        BEQ     BRPTSET ; Yes: Set breakpoint cmd       * FFAB 27 8C
        CMPA    #'H     ; Is it `H` ?                   * FFAD 81 48
        BEQ     HEADER  ; Yes:                          * FFAF 27 B2
        CMPA    #'P     ; Is it `P` ?                   * FFB1 81 50
        BNE     L1      ; No: Skip JMP                  * FFB3 26 03
        JMP     PUNCH   ;                               * FFB5 7E FCD8
L1      CMPA    #'L     ; Is it `L` ?                   * FFB8 81 4C
        BNE     L2      ; No: Skip JMP                  * FFBA 26 03
        JMP     LOAD    ;                               * FFBC 7E FD07
L2      CMPA    #'R     ; Is it `R`                     * FFBF 81 52
        BNE     L3      ; No: Skip JMP                  * FFC1 26 03
        JMP     REGPRT  ;                               * FFC3 7E FD36
L3      CMPA    #'B     ; Is it `B` ?                   * FFC6 81 42
        BNE     L4      ; No: Skip JMP                  * FFC8 26 03
        JMP     BLKMOV  ;                               * FFCA 7E FD62
L4      CMPA    #'Z     ; Is it `Z` ?                   * FFCD 81 5A
        BNE     L5      ; No: Skip JMP                  * FFCF 26 03
        JMP     CMD_Z   ;                               * FFD1 7E FDE2
L5      CMPA    #'58    ;       Is it `X` ?             * FFD4 81 58
        BNE     L6      ; No: Skip JMP                  * FFD6 26 03
        JMP     CMD_X   ;                               * FFD8 7E FE1C
L6      CMPA    #'M     ; Is it `M` ?                   * FFDB 81 4D
        BNE     L8      ; No: Skip JMP                  * FFDD 26 03
        JMP     MODIFY  ;                               * FFDF 7E FE43
                        ; Note: `A` removed             *
                        ;                               *
L8      CMPA    #'G     ; Is it `G` ?                   * FFE2 81 47
        BNE     L9      ; No: Skip JMP                  * FFE4 26 03
        JMP     GO      ;                               * FFE6 7E FEC2
L9      CMPA    #'C     ; Is it `C` ?                   * FFE9 81 43
        BNE     L10     ; No: Skip JMP                  * FFEB 26 03
        JMP     CONTNU  ;                               * FFED 7E FED9
L10     CMPA    #'D     ; Is it `D` ?                   * FFF0 81 44
        BNE     START   ; No: Give up - ignore comand   * FFF2 26 9B
        JMP     DUMP    ;                               * FFF4 7E FF07

; -----------------------------------------------------
        ORG     $FFF8   ; 6800 interrupt vectors
        FDB     JIRQ    ; IRQ                           * FFF8 F0 E0
        FDB     SWI     ; SWI                           * FFFA FF 8C 
        FDB     JNMI    ; NMI                           * FFFC F0 DD
        FDB     RESET   ; Reset                         * FFFE FF 81
; -----------------------------------------------------
;       The End



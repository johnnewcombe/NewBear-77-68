TSC 8K BASIC derived from the C code of this project: http://www.torok.info/computing/SWTPC/index.htm

Note: BASIC looks for a PIA or ACIA directly and does not use monitor routines for I/O. Modified at 0042H to move the PIA/ACIA address to 8000H from 8004H.

To launch type J 0100
